package com.example.demo.controller;

import com.example.demo.dto.ApiResponse;
import com.example.demo.model.Book;
import com.example.demo.service.BookService;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/books")
public class BookController {

    @Autowired
    private BookService service;

    // All users can view all books
    @GetMapping
    public List<Book> getAllBooks() {
        return service.getAllBooks();
    }

    // All users can view a single book
    @GetMapping("/{isbn}")
    public ResponseEntity<Book> getBook(@PathVariable String isbn) {
        return service.getBookByIsbn(isbn)
                .map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }

    // All users can create a book
    @PostMapping
    public ResponseEntity<ApiResponse> createBook(@Valid @RequestBody Book book) {
        service.addBook(book);
        return ResponseEntity.ok(new ApiResponse("Book added successfully"));
    }

    // All users can update a book
    @PutMapping("/{isbn}")
    public ResponseEntity<ApiResponse> updateBook(@PathVariable String isbn, @Valid @RequestBody Book book) {
        service.updateBook(isbn, book);
        return ResponseEntity.ok(new ApiResponse("Book updated successfully"));
    }

    // All users can delete a book
    @DeleteMapping("/{isbn}")
    public ResponseEntity<ApiResponse> deleteBook(@PathVariable String isbn) {
        service.deleteBook(isbn);
        return ResponseEntity.ok(new ApiResponse("Book deleted successfully"));
    }
}
