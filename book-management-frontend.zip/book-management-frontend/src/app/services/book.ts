import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Book } from '../models/book.model';

@Injectable({
  providedIn: 'root'
})
export class BookService {

  private baseUrl = 'http://localhost:8084/books';

  constructor(private http: HttpClient) { }

  // Get all books
  getBooks(): Observable<Book[]> {
    return this.http.get<Book[]>(`${this.baseUrl}`);
  }

  // Get a book by ISBN
  getBookByIsbn(isbn: string): Observable<Book> {
    return this.http.get<Book>(`${this.baseUrl}/${isbn}`);
  }

  // Add a new book
  addBook(book: Book): Observable<any> {
    return this.http.post(`${this.baseUrl}`, book);
  }

  // Update an existing book
  updateBook(isbn: string, book: Book): Observable<any> {
    return this.http.put(`${this.baseUrl}/${isbn}`, book);
  }

  // Delete a book by ISBN
  deleteBook(isbn: string): Observable<any> {
    return this.http.delete(`${this.baseUrl}/${isbn}`);
  }
}
