export interface Book {
  title: string;
  author: string;
  isbn: string;
  publicationYear: number;
}
