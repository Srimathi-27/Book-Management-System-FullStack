import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { Login } from './components/auth/login/login';
import { ListBooks } from './components/book/list-books/list-books';
import { AddBook } from './components/book/add-book/add-book';
import { EditBook } from './components/book/edit-book/edit-book';
import { AuthGuard } from './guards/auth-guard';
import { Register } from './components/auth/register/register';

const routes: Routes = [
  { path: '', redirectTo: 'login', pathMatch: 'full' },
  { path: 'login', component: Login },
  { path: 'register', component: Register },
  { path: 'books', component: ListBooks, canActivate: [AuthGuard] },
  { path: 'add', component: AddBook, canActivate: [AuthGuard] },
  { path: 'edit/:isbn', component: EditBook, canActivate: [AuthGuard] },
  { path: '**', redirectTo: 'login' }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
