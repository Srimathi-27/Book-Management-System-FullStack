import { NgModule, importProvidersFrom } from '@angular/core';
import { BrowserModule, bootstrapApplication } from '@angular/platform-browser';
import { HttpClientModule, HTTP_INTERCEPTORS, provideHttpClient, withFetch } from '@angular/common/http';
import { ReactiveFormsModule } from '@angular/forms';

import { AppRoutingModule } from './app-routing-module';
import { App } from './app';
import { Login } from './components/auth/login/login';
import { ListBooks } from './components/book/list-books/list-books';
import { AddBook } from './components/book/add-book/add-book';
import { EditBook } from './components/book/edit-book/edit-book';
import { Navbar } from './components/shared/navbar/navbar';
import { Register } from './components/auth/register/register';

import { AuthInterceptor } from './interceptors/auth-interceptor';

@NgModule({
  declarations: [
    App,
    Login,
    ListBooks,
    AddBook,
    EditBook,
    Navbar,
    Register
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    HttpClientModule,
    ReactiveFormsModule
  ],
  providers: [
    {
      provide: HTTP_INTERCEPTORS,
      useClass: AuthInterceptor,
      multi: true
    },
    // ✅ Enable Fetch instead of XHR
    provideHttpClient(withFetch())
  ],
  bootstrap: [App]
})
export class AppModule {}
