import { Component } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { BookService } from '../../../services/book';
import Swal from 'sweetalert2';

@Component({
  selector: 'app-edit-book',
  standalone: false,
  templateUrl: './edit-book.html',
  styleUrl: './edit-book.css'
})
export class EditBook {
  bookForm!: FormGroup;
  submitted = false;
  isbn!: string;

  constructor(
    private route: ActivatedRoute,
    private fb: FormBuilder,
    private bookService: BookService,
    private router: Router
  ) {}

  ngOnInit(): void {
    this.isbn = this.route.snapshot.paramMap.get('isbn') || '';

    this.bookForm = this.fb.group({
      title: ['', Validators.required],
      author: ['', Validators.required],
      isbn: [{ value: '', disabled: true }], // disabled so user can't change it
      publicationYear: ['', [Validators.required, Validators.pattern(/^\d{4}$/)]]
    });

    this.bookService.getBookByIsbn(this.isbn).subscribe({
      next: (book) => {
        this.bookForm.patchValue(book);
      },
      error: () => alert('Failed to load book')
    });
  }

  get f() {
    return this.bookForm.controls;
  }

  onSubmit(): void {
  this.submitted = true;
  if (this.bookForm.invalid) return;

  const updatedBook = {
    ...this.bookForm.getRawValue(), // includes disabled isbn
    isbn: this.isbn
  };

  this.bookService.updateBook(this.isbn, updatedBook).subscribe({
    next: () => {
      Swal.fire({
        icon: 'success',
        title: 'Book Updated!',
        text: '📘 The book details were updated successfully.',
        timer: 2000,
        showConfirmButton: false
      }).then(() => {
        this.router.navigate(['/books']);
      });
    },
    error: () => {
      Swal.fire({
        icon: 'error',
        title: 'Update Failed',
        text: '❌ Could not update the book. Try again later.',
        confirmButtonColor: '#dc3545'
      });
    }
  });
}


  onCancel(): void {
    this.router.navigate(['/books']);
  }

}
