import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Book } from '../../../models/book.model';
import { BookService } from '../../../services/book';

@Component({
  selector: 'app-list-books',
  standalone: false,
  templateUrl: './list-books.html',
  styleUrls: ['./list-books.css']
})
export class ListBooks implements OnInit {
  books: Book[] = [];

  constructor(
    private bookService: BookService,
    private router: Router
  ) {}

  ngOnInit(): void {
    this.loadBooks();
  }

  loadBooks(): void {
    this.bookService.getBooks().subscribe({
      next: (data) => {
        this.books = data;
      },
      error: () => {
        alert('Error loading books');
      }
    });
  }

  deleteBook(isbn: string): void {
    if (confirm('Are you sure you want to delete this book?')) {
      this.bookService.deleteBook(isbn).subscribe({
        next: () => this.loadBooks(),
        error: () => alert('Failed to delete book')
      });
    }
  }

  editBook(isbn: string): void {
    this.router.navigate(['/edit', isbn]);
  }

  addBook(): void {
    this.router.navigate(['/add']);
  }
}
