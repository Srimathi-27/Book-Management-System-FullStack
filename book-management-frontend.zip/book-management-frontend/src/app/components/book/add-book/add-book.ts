import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { BookService } from '../../../services/book';
import { Router } from '@angular/router';
import Swal from 'sweetalert2';

@Component({
  selector: 'app-add-book',
  standalone: false,
  templateUrl: './add-book.html',
  styleUrls: ['./add-book.css'] 
})
export class AddBook implements OnInit {
  bookForm!: FormGroup;
  submitted = false;

  constructor(
    private fb: FormBuilder,
    private bookService: BookService,
    private router: Router
  ) {}

  ngOnInit(): void {
    this.bookForm = this.fb.group({
      title: ['', Validators.required],
      author: ['', Validators.required],
      isbn: ['', [Validators.required, Validators.pattern(/^\d{4}$/)]], // exactly 4 digits
      publicationYear: ['', [Validators.required, Validators.pattern(/^\d{4}$/)]]
    });
  }

  get f() {
    return this.bookForm.controls;
  }

  onSubmit(): void {
  this.submitted = true;

  if (this.bookForm.invalid) return;

  this.bookService.addBook(this.bookForm.value).subscribe({
    next: () => {
      Swal.fire({
        icon: 'success',
        title: 'Book Added!',
        text: '✅ Your book has been added successfully.',
        timer: 2000,
        showConfirmButton: false
      });

      // Optional: slight delay to allow user to see the message
      setTimeout(() => {
        this.router.navigate(['/books']);
      }, 2000);
    },
    error: () => {
      Swal.fire({
        icon: 'error',
        title: 'Oops!',
        text: '❌ Failed to add book. Please try again.',
        confirmButtonColor: '#dc3545'
      });
    }
  });
}

  onReset(): void {
    this.bookForm.reset();
    this.submitted = false;
  }
}
