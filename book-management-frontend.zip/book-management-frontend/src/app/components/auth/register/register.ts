import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators, AbstractControl } from '@angular/forms';
import { Router } from '@angular/router';
import { AuthService } from '../../../services/auth';
import Swal from 'sweetalert2';

@Component({
  selector: 'app-register',
  standalone: false,
  templateUrl: './register.html',
  styleUrl: './register.css'
})
export class Register implements OnInit {
  registerForm!: FormGroup;
  submitted = false;
  errorMessage = '';
  successMessage = '';

  constructor(
    private fb: FormBuilder,
    private authService: AuthService,
    private router: Router
  ) {}

  ngOnInit(): void {
    this.registerForm = this.fb.group({
      username: ['', Validators.required],
      password: ['', [Validators.required, Validators.minLength(6)]],
      confirmPassword: ['', Validators.required]
    }, {
      validators: this.passwordsMatchValidator
    });

    // Ensure confirmPassword validity updates when password changes
    this.registerForm.get('password')?.valueChanges.subscribe(() => {
      this.registerForm.get('confirmPassword')?.updateValueAndValidity();
    });
  }

  get f(): { [key: string]: AbstractControl } {
    return this.registerForm.controls;
  }

  passwordsMatchValidator(group: FormGroup): { [key: string]: any } | null {
    const password = group.get('password');
    const confirmPassword = group.get('confirmPassword');
    return password && confirmPassword && password.value === confirmPassword.value
      ? null
      : { mismatch: true };
  }

  onRegister(): void {
  this.submitted = true;
  this.errorMessage = '';
  this.successMessage = '';

  if (this.registerForm.invalid) return;

  const { username, password } = this.registerForm.value;

  this.authService.register({ username, password }).subscribe({
    next: () => {
      Swal.fire({
        icon: 'success',
        title: 'Registered!',
        text: '🎉 Your account has been created.',
        timer: 2000,
        showConfirmButton: false
      }).then(() => {
        this.router.navigate(['/login']);
      });

      this.registerForm.reset();
      this.submitted = false;
    },
    error: (err) => {
      console.error('Registration error:', err);
      Swal.fire({
        icon: 'error',
        title: 'Registration Failed',
        text: '❌ Try a different username.',
        confirmButtonColor: '#dc3545'
      });
    }
  });
}
}
