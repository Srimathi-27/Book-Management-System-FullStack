import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators, AbstractControl } from '@angular/forms';
import { AuthService } from '../../../services/auth';
import { Router } from '@angular/router';
import Swal from 'sweetalert2';

@Component({
  selector: 'app-login',
  standalone: false,
  templateUrl: './login.html',
  styleUrls: ['./login.css']
})
export class Login implements OnInit {
  loginForm!: FormGroup;
  submitted = false;
  loginError = '';

  constructor(
    private fb: FormBuilder,
    private auth: AuthService,
    private router: Router
  ) {}

  ngOnInit(): void {
    this.loginForm = this.fb.group({
      username: ['', Validators.required],
      password: ['', Validators.required]
    });
  }

  get f(): { [key: string]: AbstractControl } {
    return this.loginForm.controls;
  }

  onLogin(): void {
  this.submitted = true;
  this.loginError = '';

  if (this.loginForm.invalid) return;

  this.auth.login(this.loginForm.value).subscribe({
    next: (res) => {
      this.auth.setToken(res.token);

      Swal.fire({
        icon: 'success',
        title: 'Welcome!',
        text: '🎉 Login successful!',
        timer: 2000,
        showConfirmButton: false
      }).then(() => {
        this.router.navigate(['/books']);
      });
    },
    error: () => {
      this.loginError = '❌ Invalid username or password.';
      Swal.fire({
        icon: 'error',
        title: 'Login Failed',
        text: this.loginError,
        confirmButtonColor: '#dc3545'
      });
    }
  });
}
}
